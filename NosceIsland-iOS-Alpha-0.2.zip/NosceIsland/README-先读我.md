# Nosce Island · iOS Alpha 0.2

本次更新：品牌更名为 Nosce Island；采用原先方向的薄荷绿波形标志；行情切换为 Hyperliquid。猫头鹰方案已从本工程移除。

这是可在 Xcode 中打开的原生 SwiftUI / ActivityKit 源码工程，不是已签名 IPA。当前环境没有 Xcode 和 Apple SDK，尚未完成 iOS 编译、签名和真机验证。

## 已编写的功能

- 首页、自选、设置；中英文跟随系统，支持红涨绿跌 / 绿涨红跌。
- App 图标、首页和实时活动采用统一的波形标志，包含可编辑 SVG 源文件。
- 前台通过 `wss://api.hyperliquid.xyz/ws` 订阅选中品种的 `activeAssetCtx`，接收标记价与 24h 参考价；不再按原版的 5 秒轮询方式请求 Coinbase。
- 断线按 1–30 秒退避重连，定期心跳，超过 30 秒无有效数据重新连接。报价过期会明确标记，不生成虚假价格。
- 首次连接先用 `metaAndAssetCtxs` 加载快照，再消费 WebSocket 更新。
- 自选列表通过 `perpDexs` 和各市场 `meta` 动态加载并缓存，支持搜索完整平台代码及 HIP-3 市场。
- 不同市场相同代码保留独立 ID（例如 xyz 与其他 dex 的同名合约），不会合并为一个资产。
- 自选最多 2 个；紧凑灵动岛显示第一个，长按展开和锁屏显示两个。
- 真实行情在界面中流式更新；前台更新实时活动最多约每 5 秒一次，避免向系统提交每一条行情。
- 固定示例模式用于离线验证布局；明确标记演示。
- 无账号、广告和收费；没有人为付费续时限制。

## 行情的准确含义

显示的是 **Hyperliquid 永续合约标记价 `markPx`**，不是现货最新成交价或订单簿中间价。

24h 涨跌幅按 `(markPx / prevDayPx - 1) × 100` 计算；参考价无效时显示空值。显示时间是本机收到数据的时间，因为该通道没有逐条交易所成交时间。

HIP-3 列表包含股票相关、商品、指数及其他永续合约。比如 `xyz:TSLA` 是平台的相关合约，不能当成纳斯达克股票的官方报价。所有价格按 API 的 USD 报价单位显示，不把标的所在地的货币当成实际报价币种。

港股覆盖取决于平台实际上架品种，本版不假装支持全港股。BABA 等美股代码也不自动映射为 9988.HK。找不到的品种请先检查平台是否上架；缓存中的种子代码也必须收到有效报价后才能开启活动。

## 当前最重要的限制

**本地版切到后台后停止连接，不能作为完整的后台实时盯盘服务使用。** 灵动岛保留最后一次报价，并在 30 秒后标记过期。后台持续刷新仍需服务器接行情及 APNs / ActivityKit 推送配置。

苹果实时活动单次最长 8 小时，实际可被系统或用户更早结束。不能保证全天常驻或每秒刷新。当前没有到价提醒、持仓盈亏、桌面小组件或付费系统。

## 安装到自己的 iPhone

1. 在 Mac 安装能支持手机 iOS 版本的最新版 Xcode，首次启动按提示安装 iOS 平台。
2. 解压后打开 `NosceIsland.xcodeproj`。顶部 Scheme 选择 `NosceIsland`。
3. Xcode → Settings → Accounts，登录自己的 Apple 账号。
4. 左侧蓝色工程图标 → TARGETS，分别选择 `NosceIsland` 和 `NosceIslandLive` → Signing & Capabilities。两个目标都勾选 Automatically manage signing，并选择同一个 Personal Team。
5. 如 Bundle Identifier 被占用，两个目标分别改成独特的 `com.你的英文名.nosceisland` 和 `com.你的英文名.nosceisland.live`。扩展 ID 必须保持主 App ID 加 `.live` 的前缀关系。
6. 连接 iPhone，解锁并信任 Mac。按 Xcode 提示开启手机“设置 → 隐私与安全性 → 开发者模式”，需要时重启。
7. 顶部运行设备选自己的 iPhone，按 Command-R。首次可能需要在手机“设置 → 通用 → VPN 与设备管理”信任开发者。
8. 打开 App 等待 BTC 报价；进入自选搜索 TSLA，选择 `xyz:TSLA` 验证第二个合约。默认最多两个，换品种前可以在“已选择”中移除。
9. 回首页点“显示到灵动岛”。按系统提示允许实时活动；若未出现，检查 iPhone 设置中的本 App 实时活动权限。无灵动岛的机型可测试锁屏。
10. 回桌面、长按灵动岛、锁屏分别查看。离开 App 后本版不更新，30 秒后过期；回 App 应恢复连接。

普通 Personal Team 的设备安装配置约 7 天失效，需重新构建安装；TestFlight 和完整后台推送属于后续开发者服务配置阶段。

## 验证状态

本环境已实际请求 Hyperliquid 原生市场及 xyz 市场的 REST 快照，并通过 WebSocket 收到 BTC 与 `xyz:TSLA` 的 `activeAssetCtx`。实测消息保存在 `Tests/Fixtures`，仅用于解码测试，不作为 App 的真实行情回退数据。

已完成 Swift 语法解析、Xcode 工程引用、资源目录、Info.plist、Scheme XML 和图标尺寸检查。这些检查不能替代 Xcode 类型检查与真机测试。

Mac 上可运行以下命令检查真实消息解码、无效数值、缺失参考价和市场命名空间：

```bash
bash Tests/run-wire-checks.sh
```

模拟器编译检查：

```bash
xcodebuild -project NosceIsland.xcodeproj -scheme NosceIsland -sdk iphonesimulator -configuration Debug -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

若遇错误，请发 Xcode 第一条红色错误的完整文字，不要发送账号密码、密钥或手机标识。

## 主要文件

- `App/MarketStore.swift`：市场发现、实时连接、重连、活动生命周期。
- `Shared/HyperliquidWire.swift`：与实际 API 消息对应的解码模型。
- `App/ContentView.swift`：界面与来源 / 过期提示。
- `LiveActivity/NosceLiveActivity.swift`：灵动岛与锁屏。
- `Brand/Nosce-Wave.svg`：App 图标矢量源文件。

## 官方接口依据

https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint/perpetuals

https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/websocket/subscriptions

https://developer.apple.com/documentation/ActivityKit/displaying-live-data-with-live-activities
