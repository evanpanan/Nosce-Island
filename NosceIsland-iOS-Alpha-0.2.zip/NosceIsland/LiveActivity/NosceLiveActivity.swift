import WidgetKit
import SwiftUI
import ActivityKit

@main struct NosceWidgets: WidgetBundle {
    var body: some Widget { NosceLiveActivity() }
}
struct NosceLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: MarketActivityAttributes.self) { context in
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label { Text("NOSCE ISLAND") } icon: { Image("WaveMark").resizable().scaledToFit().frame(width: 16, height: 16) }.font(.caption2.bold()).foregroundStyle(.mint)
                    Spacer()
                    status(context)
                }
                ForEach(context.state.quotes) { quote in row(quote, redUp: context.state.redUp) }
                Text(local("合约标记价 · 本地版后台不刷新", "Perp mark price · no background refresh"))
                    .font(.caption2).foregroundStyle(.secondary)
            }.padding(16)
                .activityBackgroundTint(Color(red: 0.045, green: 0.06, blue: 0.065))
                .activitySystemActionForegroundColor(.white)
                .widgetURL(URL(string: "nosceisland://watch"))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label { Text("NOSCE") } icon: { Image("WaveMark").resizable().scaledToFit().frame(width: 16, height: 16) }.font(.caption.bold()).foregroundStyle(.mint)
                }
                DynamicIslandExpandedRegion(.trailing) { status(context) }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 10) {
                        ForEach(context.state.quotes) { quote in row(quote, redUp: context.state.redUp) }
                        Text(local("合约标记价 · 本地版后台不刷新", "Perp mark price · no background refresh"))
                            .font(.caption2).foregroundStyle(.secondary)
                    }.padding(.vertical, 6)
                }
            } compactLeading: {
                HStack(spacing: 3) {
                    if context.isStale || context.state.quotes.contains(where: { $0.demo }) {
                        Image(systemName: "exclamationmark.circle").foregroundStyle(.orange).font(.caption2)
                    }
                    Text(context.state.quotes.first?.symbol ?? "—").font(.caption2.bold())
                }
            } compactTrailing: {
                Text(context.state.quotes.first?.formattedPrice ?? "—")
                    .font(.caption2.monospacedDigit()).lineLimit(1).minimumScaleFactor(0.6)
                    .foregroundStyle(context.isStale ? .orange : .white)
            } minimal: {
                if context.isStale {
                    Image(systemName: "exclamationmark.circle").foregroundStyle(.orange)
                } else {
                    Image("WaveMark").resizable().scaledToFit()
                }
            }
            .widgetURL(URL(string: "nosceisland://watch"))
            .keylineTint(.mint)
        }
    }
    private func local(_ zh: String, _ en: String) -> String {
        Locale.preferredLanguages.first?.hasPrefix("zh") == true ? zh : en
    }
    private func status(_ context: ActivityViewContext<MarketActivityAttributes>) -> some View {
        let demo = context.state.quotes.contains { $0.demo }
        return Text(demo ? local("演示", "DEMO") : context.isStale ? local("已过期", "STALE") : local("前台更新", "FOREGROUND"))
            .font(.caption2.bold()).foregroundStyle(demo || context.isStale ? .orange : .secondary)
    }
    private func row(_ quote: IslandQuote, redUp: Bool) -> some View {
        HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 3) {
                Text(quote.symbol).font(.headline)
                Text(quote.demo ? local("示例价格", "SAMPLE") : quote.source + " · " + local("接收 ", "Received ") + quote.updatedAt.formatted(date: .omitted, time: .standard))
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Text(quote.formattedPrice).font(.headline.monospacedDigit()).lineLimit(1).minimumScaleFactor(0.6)
            if let change = quote.change {
                Text(quote.formattedChange).font(.caption.monospacedDigit())
                    .foregroundStyle((change >= 0) != redUp ? .mint : .red)
            }
        }
    }
}
