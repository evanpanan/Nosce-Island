import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: MarketStore
    @State private var tab = 0
    @State private var search = ""
    @State private var market = "All"
    
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { dashboard }
                .tabItem { Label(tr("盯盘", "Watch"), systemImage: "waveform.path") }.tag(0)
            NavigationStack { instruments }
                .tabItem { Label(tr("自选", "Watchlist"), systemImage: "star") }.tag(1)
            NavigationStack { settings }
                .tabItem { Label(tr("设置", "Settings"), systemImage: "slider.horizontal.3") }.tag(2)
        }
        .tint(.mint)
        .task { store.startRefreshing() }
        .alert(tr("提示", "Notice"), isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(tr("知道了", "OK")) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
    private var dashboard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack {
                    HStack(spacing: 8) { Image("WaveMark").resizable().scaledToFit().frame(width: 28, height: 28); Text("NOSCE ISLAND").font(.caption.bold()).tracking(2) }
                    Spacer()
                    Text("ALPHA 0.2").font(.caption2.monospaced()).foregroundStyle(.secondary)
                }.foregroundStyle(.mint)
                VStack(alignment: .leading, spacing: 8) {
                    Text(tr("行情，抬眼即见。", "Markets. At a glance.")).font(.largeTitle.bold())
                    Text(tr("无强制广告 · 无付费倒计时", "No forced ads. No paid countdown."))
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                VStack(spacing: 20) {
                    HStack {
                        Text(tr("灵动岛预览", "ISLAND PREVIEW")).font(.caption.bold()).foregroundStyle(.secondary)
                        Spacer()
                        Text(store.demo ? tr("演示", "DEMO") : tr("前台行情", "FOREGROUND"))
                            .font(.caption2.bold()).foregroundStyle(store.demo ? .orange : .mint)
                    }
                    HStack(spacing: 12) {
                        Image("WaveMark").resizable().scaledToFit().frame(width: 22, height: 22)
                        Text(store.islandQuotes.first?.symbol ?? "BTC").font(.caption.bold())
                        Spacer(minLength: 4)
                        Text(store.islandQuotes.first?.formattedPrice ?? "—").font(.callout.monospacedDigit().bold()).lineLimit(1).minimumScaleFactor(0.6)
                    }.padding(.horizontal, 20).frame(height: 46)
                        .background(.black, in: Capsule()).padding(.horizontal, 20)
                    HStack {
                        Image(systemName: "hand.draw").foregroundStyle(.secondary)
                        Text(tr("长按真实灵动岛，可查看展开行情。", "Touch and hold the real island for expanded quotes."))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(20).background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 26))
                HStack {
                    Text(tr("正在关注", "Your watch")).font(.title3.bold())
                    Spacer()
                    Button { tab = 1 } label: { Image(systemName: "plus.circle").font(.title3) }
                        .accessibilityLabel(tr("添加资产", "Add instrument"))
                }
                Text(store.connection).font(.caption).foregroundStyle(.secondary)
                ForEach(store.chosen) { item in quoteCard(item) }
                VStack(alignment: .leading, spacing: 10) {
                    Label(tr("本地测试版", "Local testing build"), systemImage: "info.circle").font(.subheadline.bold())
                    Text(tr("Hyperliquid 永续合约标记价，前台采用流式连接。股票相关合约不等于交易所股票报价。本地版后台不持续刷新，报价会标记过期。", "Hyperliquid perpetual mark prices, streamed in the foreground. Equity-linked contracts are not exchange stock quotes. Background streaming is not enabled in this local build; stale data is marked."))
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.mint.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
                Button {
                    Task { if store.activityRunning { await store.endActivity() } else { await store.startActivity() } }
                } label: {
                    Label(store.activityRunning ? tr("结束盯盘", "Stop watching") : tr("显示到灵动岛", "Show on Dynamic Island"),
                          systemImage: store.activityRunning ? "stop.circle" : "waveform.path")
                        .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 19)
                }.buttonStyle(.borderedProminent).tint(store.activityRunning ? .gray : .mint).foregroundStyle(.black)
                Text(tr("实时活动受 iOS 管理，单次最长 8 小时；本版不人为缩短。", "iOS manages Live Activities, with an 8-hour maximum per session. No shorter app-imposed timer."))
                    .font(.caption2).foregroundStyle(.secondary)
            }.padding(20)
        }.background(Color(red: 0.035, green: 0.045, blue: 0.055)).toolbar(.hidden, for: .navigationBar)
    }
    private func quoteCard(_ item: Instrument) -> some View {
        let quote = store.quotes[item.id]
        return VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.symbol).font(.headline)
                    Text(item.id + " · " + tr("永续合约", "Perpetual")).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Text(quote?.formattedPrice ?? "—").font(.title3.monospacedDigit().bold())
                    Text((quote?.formattedChange ?? "—") + " · 24h").font(.caption.monospacedDigit()).foregroundStyle(store.color(quote?.change))
                }
            }
            if !store.demo, let points = store.history[item.id], points.count > 1 {
                Sparkline(values: points).stroke(.mint, style: StrokeStyle(lineWidth: 2, lineCap: .round)).frame(height: 44)
                Text(tr("本次打开期间采样", "Samples since opening")).font(.caption2).foregroundStyle(.secondary)
            }
            if let error = store.errors[item.id] {
                Label(error, systemImage: "exclamationmark.circle").font(.caption).foregroundStyle(.orange)
            }
            if let quote {
                TimelineView(.periodic(from: .now, by: 5)) { context in
                    HStack {
                        Circle().fill(quote.demo ? .orange : context.date.timeIntervalSince(quote.updatedAt) > 30 ? .orange : .mint).frame(width: 5, height: 5)
                        Text(quote.demo ? tr("示例价格，非真实行情", "Sample price, not market data") : quote.source + " · " + tr("接收于 ", "Received ") + quote.updatedAt.formatted(date: .omitted, time: .standard))
                            .font(.caption2).foregroundStyle(.secondary)
                        if !quote.demo && context.date.timeIntervalSince(quote.updatedAt) > 30 { Text(tr("过期", "STALE")).font(.caption2.bold()).foregroundStyle(.orange) }
                    }
                }
            } else if store.loading { ProgressView().controlSize(.small) }
        }.padding(18).background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
    }
    private var instruments: some View {
        List {
            Section {
                Picker(tr("市场", "Market"), selection: $market) {
                    Text(tr("全部", "All")).tag("All")
                    Text(tr("加密", "Crypto")).tag("Crypto")
                    Text("HIP-3").tag("HIP-3")
                }.pickerStyle(.segmented)
            }
            Section {
                Text(tr("这里是合约市场。HIP-3 包含股票相关及其他合约，不代表港美股交易所报价；找不到的品种可能尚未上架。", "These are perpetual markets. HIP-3 includes equity-linked and other contracts, not stock exchange quotes. Missing instruments may not be listed."))
                    .font(.caption).foregroundStyle(.secondary)
                if store.catalogLoading { ProgressView(tr("正在加载市场…", "Loading markets…")) }
                if let notice = store.catalogNotice { Text(notice).font(.caption).foregroundStyle(.orange) }
                Button(tr("刷新市场列表", "Reload markets")) { store.reloadCatalog() }.disabled(store.catalogLoading)
            }
            Section(tr("已选择 · 点按移除", "Selected · tap to remove")) {
                ForEach(store.chosen) { item in
                    Button { store.toggle(item) } label: {
                        HStack { Text(item.id); Spacer(); Image(systemName: "minus.circle") }
                    }
                }
            }
            Section(tr("选择 1–2 个资产，首个显示在紧凑灵动岛", "Choose 1–2; first asset appears in compact island")) {
                ForEach(store.catalog.filter {
                    (market == "All" || $0.market == market) &&
                    (search.isEmpty || ($0.id).localizedCaseInsensitiveContains(search))
                }) { item in
                    Button { store.toggle(item) } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.symbol).font(.headline).foregroundStyle(.primary)
                                Text(item.id + " · " + tr("永续合约", "Perpetual"))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: store.selected.contains(item.id) ? "checkmark.circle.fill" : "plus.circle")
                        }.padding(.vertical, 6)
                    }.accessibilityLabel(item.symbol + (store.selected.contains(item.id) ? tr(" 已选择", " selected") : tr(" 添加", " add")))
                }
            }
        }.navigationTitle(tr("自选行情", "Watchlist"))
            .searchable(text: $search, prompt: tr("搜索代码或英文名称", "Symbol or name"))
    }
    private var settings: some View {
        Form {
            Section(tr("显示", "Display")) {
                Toggle(tr("红涨绿跌", "Red for gains"), isOn: $store.redUp)
                    .onChange(of: store.redUp) { value in
                        UserDefaults.standard.set(value, forKey: "redUp")
                        Task { await store.updateActivity() }
                    }
                LabeledContent(tr("语言", "Language"), value: tr("跟随系统", "System"))
                LabeledContent(tr("币种", "Currency"), value: tr("USD 报价单位", "USD quote units"))
            }
            Section {
                Toggle(tr("示例行情模式", "Sample data mode"), isOn: $store.demo)
                    .onChange(of: store.demo) { _ in Task { await store.changeMode() } }
            } footer: {
                Text(tr("固定示例价格只用于验证布局，不代表当前行情。切换模式会结束已有实时活动。", "Fixed samples preview layouts and are not current prices. Switching mode ends the active Live Activity."))
            }
            Section(tr("测试能力", "Testing scope")) {
                Label(tr("原生灵动岛与锁屏显示", "Native island and Lock Screen"), systemImage: "checkmark.circle")
                Label(tr("无广告、无账号、无收费", "No ads, account or payments"), systemImage: "checkmark.circle")
                Label(tr("后台推送：尚未配置", "Background push: not configured"), systemImage: "clock")
                Label(tr("Hyperliquid · 永续合约标记价", "Hyperliquid · perpetual mark prices"), systemImage: "waveform.path")
                Text(tr("本版没有到价提醒、持仓和桌面小组件。", "Alerts, portfolio and Home Screen widgets are not in this build.")).font(.caption).foregroundStyle(.secondary)
            }
            Section {
                Text("Nosce Island · 0.2 Alpha").font(.subheadline.bold())
                Text(tr("行情源：Hyperliquid。显示永续合约标记价；24h 涨跌幅相对 prevDayPx 计算。股票相关合约可能偏离交易所价格，港股品种以平台实际上架为准。时间显示本机接收时间，不是交易所成交时间。", "Source: Hyperliquid perpetual mark prices. 24h change uses prevDayPx. Equity-linked contracts may differ from stock exchange prices; HK coverage depends on actual listings. Times are local receipt times, not trade timestamps."))
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle(tr("设置", "Settings"))
    }
}

struct Sparkline: Shape {
    let values: [Double]
    func path(in rect: CGRect) -> Path {
        guard values.count > 1, let low = values.min(), let high = values.max() else { return Path() }
        let span = max(high - low, 0.000001)
        return Path { path in
            for (index, value) in values.enumerated() {
                let point = CGPoint(x: CGFloat(index) / CGFloat(values.count - 1) * rect.width,
                                    y: rect.height - CGFloat((value - low) / span) * rect.height)
                if index == 0 { path.move(to: point) } else { path.addLine(to: point) }
            }
        }
    }
}
