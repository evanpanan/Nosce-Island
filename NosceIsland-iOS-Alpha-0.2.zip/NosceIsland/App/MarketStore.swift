import SwiftUI
import ActivityKit

typealias Instrument = HLInstrument
func tr(_ chinese: String, _ english: String) -> String {
    Locale.preferredLanguages.first?.hasPrefix("zh") == true ? chinese : english
}

@MainActor final class MarketStore: ObservableObject {
    @Published var catalog: [Instrument] = Instrument.seeds
    @Published var selected: [String] = ["BTC"]
    @Published var quotes: [String: IslandQuote] = [:]
    @Published var history: [String: [Double]] = [:]
    @Published var errors: [String: String] = [:]
    @Published var demo = false
    @Published var redUp = UserDefaults.standard.bool(forKey: "redUp")
    @Published var activityRunning = false
    @Published var message: String?
    @Published var loading = false
    @Published var catalogLoading = false
    @Published var catalogNotice: String?
    @Published var connection = tr("等待连接", "Waiting")
    private var streamTask: Task<Void, Never>?
    private var heartbeat: Task<Void, Never>?
    private var socket: URLSessionWebSocketTask?
    private var discoveryTask: Task<Void, Never>?
    private var generation = UUID()
    private var foreground = false
    private var lastActivityUpdate = Date.distantPast
    private var lastDataAt = Date()
    private var sampledAt: [String: Date] = [:]
    private var watchStartedAt = Date()
    private var connectionHadData = false

    init() {
        if let data = UserDefaults.standard.data(forKey: "hlCatalog"),
           let cache = try? JSONDecoder().decode([Instrument].self, from: data), !cache.isEmpty {
            catalog = cache
        }
        if let ids = UserDefaults.standard.stringArray(forKey: "selectedHL"), !ids.isEmpty {
            selected = Array(ids.prefix(2))
        }
    }
    var chosen: [Instrument] { selected.map { Instrument(id: $0) } }
    var islandQuotes: [IslandQuote] { selected.compactMap { quotes[$0] } }
    func color(_ change: Double?) -> Color {
        guard let change else { return .secondary }
        return (change >= 0) != redUp ? .mint : .red
    }
    func toggle(_ item: Instrument) {
        if selected.contains(item.id) {
            guard selected.count > 1 else { return }
            selected.removeAll { $0 == item.id }
        } else {
            guard selected.count < 2 else {
                message = tr("测试版最多同时显示两个资产。", "This build supports two assets at once.")
                return
            }
            selected.append(item.id)
        }
        UserDefaults.standard.set(selected, forKey: "selectedHL")
        if foreground { startRefreshing() }
    }
    func startRefreshing() {
        stopRefreshing()
        foreground = true
        let token = generation
        syncActivityState()
        streamTask = Task { [weak self] in
            guard let self else { return }
            if self.demo {
                for item in self.chosen {
                    self.quotes[item.id] = IslandQuote(id: item.id, symbol: item.symbol, price: item.sample,
                        change: nil, currency: "USD", updatedAt: Date(), demo: true, source: "DEMO")
                }
                self.connection = tr("示例模式", "Demo mode")
                await self.updateActivity()
                return
            }
            await self.connectLoop(token: token)
        }
        if discoveryTask == nil { reloadCatalog() }
    }
    func stopRefreshing() {
        foreground = false
        generation = UUID()
        streamTask?.cancel(); streamTask = nil
        heartbeat?.cancel(); heartbeat = nil
        socket?.cancel(with: .goingAway, reason: nil); socket = nil
        loading = false
    }
    func changeMode() async {
        stopRefreshing()
        await endActivity()
        quotes = [:]; history = [:]; errors = [:]; sampledAt = [:]
        startRefreshing()
    }
    private func info<T: Decodable>(_ body: [String: String], as type: T.Type) async throws -> T {
        var request = URLRequest(url: URL(string: "https://api.hyperliquid.xyz/info")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        request.timeoutInterval = 12
        request.cachePolicy = .reloadIgnoringLocalCacheData
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try JSONDecoder().decode(type, from: data)
    }
    func reloadCatalog() {
        guard !catalogLoading else { return }
        catalogLoading = true
        discoveryTask = Task { [weak self] in
            guard let self else { return }
            defer { self.catalogLoading = false; self.discoveryTask = nil }
            var items = self.catalog
            var failures = 0
            do {
                let dexs = try await self.info(["type": "perpDexs"], as: [HLDex?].self)
                let names = [""] + dexs.compactMap { $0?.name }.filter { !$0.isEmpty }
                // Sequential discovery avoids bursts against public API rate limits.
                for dex in Array(Set(names)).sorted() {
                    if Task.isCancelled { return }
                    do {
                        let meta = try await self.info(["type": "meta", "dex": dex], as: HLMeta.self)
                        items.removeAll { $0.dex == dex }
                        items += meta.universe.filter { $0.isDelisted != true }.map { asset in
                            Instrument(id: dex.isEmpty || asset.name.contains(":") ? asset.name : dex + ":" + asset.name)
                        }
                        self.catalog = self.sortedCatalog(items)
                    } catch { failures += 1 }
                }
                self.catalogNotice = failures > 0 ? tr("部分市场未加载，已保留缓存，可重试。", "Some markets failed. Cached entries retained; retry available.") : nil
                if let data = try? JSONEncoder().encode(self.catalog) { UserDefaults.standard.set(data, forKey: "hlCatalog") }
            } catch {
                self.catalogNotice = tr("市场列表加载失败，显示缓存；点击重试。", "Catalog failed. Showing cached entries; tap retry.")
            }
        }
    }
    private func sortedCatalog(_ items: [Instrument]) -> [Instrument] {
        let unique = Dictionary(items.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        return unique.values.sorted {
            let a = Instrument.seeds.firstIndex(of: $0) ?? 999
            let b = Instrument.seeds.firstIndex(of: $1) ?? 999
            return a == b ? $0.id < $1.id : a < b
        }
    }
    private func connectLoop(token: UUID) async {
        var backoff = 1
        while !Task.isCancelled && token == generation {
            loading = true
            connection = tr("正在连接 Hyperliquid…", "Connecting to Hyperliquid…")
            // REST initial mark-price snapshot; stream subscriptions use the same mark-price basis.
            for dex in Set(chosen.map(\.dex)).sorted() {
                do {
                    let snapshot = try await info(["type": "metaAndAssetCtxs", "dex": dex], as: HLSnapshot.self)
                    guard !Task.isCancelled, token == generation else { return }
                    for (asset, ctx) in zip(snapshot.meta.universe, snapshot.contexts) where asset.isDelisted != true {
                        let id = dex.isEmpty || asset.name.contains(":") ? asset.name : dex + ":" + asset.name
                        if selected.contains(id) { accept(id: id, ctx: ctx) }
                    }
                } catch { /* WebSocket may still recover even when the initial REST request fails. */ }
            }
            guard !Task.isCancelled, token == generation else { return }
            let ws = URLSession.shared.webSocketTask(with: URL(string: "wss://api.hyperliquid.xyz/ws")!)
            socket = ws; ws.resume()
            lastDataAt = Date(); watchStartedAt = Date(); connectionHadData = false
            do {
                for id in selected {
                    let json: [String: Any] = ["method": "subscribe", "subscription": ["type": "activeAssetCtx", "coin": id]]
                    let data = try JSONSerialization.data(withJSONObject: json)
                    try await ws.send(.string(String(decoding: data, as: UTF8.self)))
                }
                heartbeat = Task { [weak self] in
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(10)) } catch { return }
                        guard let self, token == self.generation else { return }
                        let hasStaleAsset = self.selected.contains { id in
                            guard let date = self.quotes[id]?.updatedAt else { return true }
                            return Date().timeIntervalSince(date) > 30
                        }
                        if Date().timeIntervalSince(self.watchStartedAt) > 30 && (hasStaleAsset || Date().timeIntervalSince(self.lastDataAt) > 30) {
                            ws.cancel(with: .goingAway, reason: nil)
                            return
                        }
                        do { try await ws.send(.string("{\"method\":\"ping\"}")) }
                        catch { ws.cancel(with: .goingAway, reason: nil); return }
                    }
                }
                while !Task.isCancelled && token == generation {
                    let frame = try await ws.receive()
                    guard !Task.isCancelled, token == generation else { return }
                    let data: Data
                    switch frame {
                    case .data(let bytes): data = bytes
                    case .string(let string): data = Data(string.utf8)
                    @unknown default: continue
                    }
                    let event = try JSONDecoder().decode(HLMessage.self, from: data)
                    if event.channel == "error" { throw URLError(.badServerResponse) }
                    guard let payload = event.data, selected.contains(payload.coin), payload.ctx.price != nil else { continue }
                    lastDataAt = Date(); connectionHadData = true
                    accept(id: payload.coin, ctx: payload.ctx)
                    loading = false
                    connection = tr("Hyperliquid · 流式连接", "Hyperliquid · streaming")
                    if Date().timeIntervalSince(lastActivityUpdate) >= 5 { await updateActivity() }
                }
            } catch {
                guard !Task.isCancelled, token == generation else { return }
                connection = tr("连接中断，正在重试…", "Disconnected. Retrying…")
                for id in selected { errors[id] = tr("连接中断，保留上次报价。", "Disconnected. Last quote retained.") }
            }
            heartbeat?.cancel(); heartbeat = nil
            ws.cancel(with: .goingAway, reason: nil)
            guard !Task.isCancelled, token == generation else { return }
            if connectionHadData { backoff = 1 }
            loading = false
            do { try await Task.sleep(for: .seconds(backoff)) } catch { return }
            backoff = min(backoff * 2, 30)
        }
    }
    private func accept(id: String, ctx: HLContext) {
        guard let price = ctx.price else { return }
        let item = Instrument(id: id)
        quotes[id] = IslandQuote(id: id, symbol: item.symbol, price: price, change: ctx.change, currency: "USD",
            updatedAt: Date(), demo: false, source: "Hyperliquid" + (item.dex.isEmpty ? "" : " · " + item.dex))
        errors[id] = nil
        if Date().timeIntervalSince(sampledAt[id] ?? .distantPast) >= 1 {
            history[id, default: []].append(price)
            history[id] = Array(history[id, default: []].suffix(90))
            sampledAt[id] = Date()
        }
    }
    private var state: MarketActivityAttributes.ContentState {
        .init(quotes: islandQuotes, redUp: redUp, foregroundOnly: true)
    }
    private var staleDate: Date { islandQuotes.map { $0.updatedAt.addingTimeInterval(30) }.min() ?? Date() }
    func syncActivityState() {
        activityRunning = Activity<MarketActivityAttributes>.activities.contains { $0.activityState == .active || $0.activityState == .stale }
    }
    func startActivity() async {
        syncActivityState()
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            message = tr("请在 iPhone 设置 → Nosce Island 中允许实时活动。", "Allow Live Activities in iPhone Settings → Nosce Island."); return
        }
        guard islandQuotes.count == selected.count else {
            message = tr("请等待所有已选资产的有效报价，或开启示例模式。", "Wait for all selected quotes, or enable demo mode."); return
        }
        guard islandQuotes.allSatisfy({ Date().timeIntervalSince($0.updatedAt) < 30 }) else {
            message = tr("报价已过期，请等待连接恢复。", "Quotes are stale. Wait for reconnection."); return
        }
        if !activityRunning {
            do {
                _ = try Activity.request(attributes: MarketActivityAttributes(sessionName: "Nosce Island"),
                    content: ActivityContent(state: state, staleDate: staleDate), pushType: nil)
            } catch { message = error.localizedDescription }
        } else { await updateActivity() }
        syncActivityState()
    }
    func updateActivity() async {
        lastActivityUpdate = Date()
        for activity in Activity<MarketActivityAttributes>.activities {
            await activity.update(ActivityContent(state: state, staleDate: staleDate))
        }
        syncActivityState()
    }
    func endActivity() async {
        for activity in Activity<MarketActivityAttributes>.activities { await activity.end(nil, dismissalPolicy: .immediate) }
        syncActivityState()
    }
}
