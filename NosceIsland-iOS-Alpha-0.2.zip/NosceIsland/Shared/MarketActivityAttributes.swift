import ActivityKit
import Foundation

struct IslandQuote: Codable, Hashable, Identifiable {
    var id: String
    var symbol: String
    var price: Double
    var change: Double?
    var currency: String
    var updatedAt: Date
    var demo: Bool
    var source: String = "Hyperliquid"
    var formattedPrice: String {
        price.formatted(.currency(code: currency).precision(.fractionLength(price < 1 ? 4 : 2)))
    }
    var formattedChange: String {
        guard let change else { return "—" }
        return String(format: "%+.2f%%", change)
    }
}

struct MarketActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var quotes: [IslandQuote]
        var redUp: Bool
        var foregroundOnly: Bool
    }
    var sessionName: String
}
