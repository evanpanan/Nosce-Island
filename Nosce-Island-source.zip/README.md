# Nosce Island

A lightweight iPhone market companion with Dynamic Island and Lock Screen quote views. Includes a native iOS alpha and a mobile-friendly interactive web preview.

面向加密货币与股票相关合约的轻量行情工具，包含原生 iOS 测试工程和手机交互预览。品牌使用深色与薄荷绿波形标志。

## Contents / 目录

| Directory | Contents |
| --- | --- |
| `ios/` | SwiftUI iOS app, ActivityKit extension, icon assets, API models and decoder checks |
| `preview/` | Self-contained mobile web preview (`index.html`), no build dependencies |

## Mobile preview / 手机预览

[Open the hosted interactive preview](https://nosce-island-mobile.brawnypixie21.chatgpt.site/)

The hosted preview may require the owner's ChatGPT sign-in. It supports watchlist changes, two-asset previews, theme and language settings, and optional Hyperliquid live data.

The web Dynamic Island is a simulation inside the page. It cannot control the iPhone system Dynamic Island. Demo prices and charts are explicitly labeled and are not current market data.

本地查看：

```bash
python3 -m http.server 8080 --directory preview
```

Open `http://localhost:8080` on the development computer. To test on a phone, use a reachable address of that computer on the same network.

## iOS alpha / iPhone 测试

1. Open `ios/NosceIsland.xcodeproj` in an Xcode version that supports your phone's iOS version.
2. Choose the `NosceIsland` scheme.
3. Configure the same signing team for both `NosceIsland` and `NosceIslandLive`; use unique bundle identifiers if needed. The extension identifier must be prefixed by the main app identifier.
4. Connect your iPhone, enable Developer Mode as prompted, and run from Xcode.

Read [the detailed Chinese installation guide](ios/README-先读我.md) for capabilities, signing steps, limitations and validation status. This repository contains source code, not a signed IPA or an App Store release.

## Market data / 行情口径

- Source: Hyperliquid public API and WebSocket `activeAssetCtx`.
- Price basis: perpetual **mark price** (`markPx`); 24-hour change uses `prevDayPx`.
- Native iOS catalog discovery uses `perpDexs` and per-market `meta`. The web preview refreshes native and `xyz` market lists.
- Full market-prefixed IDs are retained so contracts with the same symbol remain distinct.
- Equity-linked contracts are not official stock exchange quotes. Hong Kong stock coverage depends on actual platform listings; US and HK symbols are not silently mapped to one another.
- Displayed times are local receipt times, not exchange trade timestamps.

## Current limitations / 当前边界

The native app is a local alpha. Its foreground stream disconnects when the app leaves the foreground. Continuous background Dynamic Island updates require a backend and Apple ActivityKit/APNs configuration, which are **not included** in this version. Stale quotes are explicitly marked.

No account system, trading, payment, advertising, portfolio or price-alert backend is implemented. The preview's theme controls are prototype features and do not imply full feature parity with the native app.

This source has not yet been compiled with Xcode or verified on an iPhone. Swift syntax, project/resources and live Hyperliquid REST/WebSocket message shapes have been checked. These do not substitute for compilation or on-device testing.

## Validation / 检查

On a Mac with Xcode:

```bash
cd ios
bash Tests/run-wire-checks.sh
xcodebuild -project NosceIsland.xcodeproj -scheme NosceIsland -sdk iphonesimulator -configuration Debug -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

`ios/Tests/Fixtures` contains captured public market messages used only for decoding tests. They are never used as an unlabeled live-data fallback.

## Official references

- [Hyperliquid perpetual market API](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint/perpetuals)
- [Hyperliquid WebSocket subscriptions](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/websocket/subscriptions)
- [Apple ActivityKit](https://developer.apple.com/documentation/ActivityKit)
